<p>Hello [USER_NAME],</p><br><p>A request has been made to recover password for your account. </p><p>Please follow below
    link to confirm your email and generate new password for your account :</p><br><a href="[CONFIRMATION_LINK]">[CONFIRMATION_LINK]</a>
<br><p>In case you have not requested new password for your account, please ignore this email.</p><br><p>Thank you,</p>
<p>[APP_NAME]</p>