<div class="row" style="height:120px;display:flex;">
    <div class="column"
         style="background-color:#00ade6;float:left;width:50%;padding-top:10px;padding-bottom:10px;padding-right:10px;padding-left:10px;">
        <div class="row" style="display:flex;">
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:5px;margin-bottom:5px;margin-right:5px;margin-left:5px;">Project Name:</p>
            </div>
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:5px;margin-bottom:5px;margin-right:5px;margin-left:5px;font-family:Kastelov;">
                    Test Customer</p>
            </div>

        </div>
        <div class="row" style="display:flex;">
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:5px;margin-bottom:5px;margin-right:5px;margin-left:5px;">Address:</p>
            </div>
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:5px;margin-bottom:5px;margin-right:5px;margin-left:5px;font-family:Kastelov;">
                    St#1</p>
            </div>

        </div>
        <div class="row" style="display:flex;">
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:5px;margin-bottom:5px;margin-right:5px;margin-left:5px;">City, State,
                    Zip:</p>
            </div>
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:5px;margin-bottom:5px;margin-right:5px;margin-left:5px;font-family:Kastelov;">
                    Abc Xyz 123</p>
            </div>

        </div>

    </div>
    <div class="column"
         style="background-color:#114050;float:left;width:50%;padding-top:10px;padding-bottom:10px;padding-right:10px;padding-left:10px;">
        <div class="row" style="display:flex;">
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:3px;margin-bottom:3px;margin-right:3px;margin-left:3px;">Location
                    Verified:</p>
            </div>
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:3px;margin-bottom:3px;margin-right:3px;margin-left:3px;font-family:Kastelov;">
                    LAT:25.30164646, LONG:25.30136164</p>
            </div>

        </div>
        <div class="row" style="display:flex;">
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:3px;margin-bottom:3px;margin-right:3px;margin-left:3px;">Inspector:</p>
            </div>
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:3px;margin-bottom:3px;margin-right:3px;margin-left:3px;font-family:Kastelov;">
                    Test User</p>
            </div>

        </div>
        <div class="row" style="display:flex;">
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:3px;margin-bottom:3px;margin-right:3px;margin-left:3px;">Claim #:</p>
            </div>
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:3px;margin-bottom:3px;margin-right:3px;margin-left:3px;font-family:Kastelov;">
                    H01234645</p>
            </div>

        </div>
        <div class="row" style="display:flex;">
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:3px;margin-bottom:3px;margin-right:3px;margin-left:3px;">Inspection
                    Date:</p>
            </div>
            <div class="column"
                 style="padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;float:left;width:50%;">
                <p style="color:white;margin-top:3px;margin-bottom:3px;margin-right:3px;margin-left:3px;font-family:Kastelov;">
                    7/4/2019</p>
            </div>

        </div>
    </div>
</div>