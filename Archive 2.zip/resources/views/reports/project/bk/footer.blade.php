<div class="row" id="footer"
     style="background-color:#00ade6;background-image:none;background-repeat:repeat;background-position:top left;background-attachment:scroll;height:80px;display:flex;">
    <div class="column"
         style="padding-left:5%;float:left;width:50%;padding-top:10px;padding-bottom:10px;padding-right:10px;">
        <p style="color:white;letter-spacing:1px;margin-top:15px;margin-bottom:15px;margin-right:15px;margin-left:15px;font-size:20px;font-family:Kastelov;">
            Powered By:<strong>
                FieldScope</strong></p>
    </div>
    <div class="column"
         style="padding-right:5%;float:left;width:50%;padding-top:10px;padding-bottom:10px;padding-left:10px;">
        <p style="text-align:right;color:white;margin-top:15px;margin-bottom:15px;margin-right:15px;margin-left:15px;font-size:20px;font-family:Kastelov;">
            Page:1 of 3</p>
    </div>
</div>