<?php
/**
 * Created by PhpStorm.
 * User: dnasir
 * Date: 10/9/2019
 * Time: 5:04 PM
 */
?>

<table   style="padding:0px 50px;">
    <tr>
        <td style="padding: 50px 0px 20px 0px;">
            <img style="width:740px; height:auto;"
                 src="{{ $map }}"></td>
    </tr>
</table>
<div class="page-break"></div>

