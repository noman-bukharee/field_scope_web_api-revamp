<table style="width: 100%; border-collapse: collapse;">
    <tr style="background-color: #d1d3d4;">
        <td colspan="2" style="padding: 10px 20px;">
            <p style="padding: 20px; margin: 0">
                Powered by :<span style="font-weight: bold">{{ucwords(config('app.name'))}}</span>
            </p>
        </td>
    </tr>
</table>