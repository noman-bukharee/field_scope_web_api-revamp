<!DOCTYPE html>
<html>
<head>
</head>
<body>
<p>
    <span style="width: 150px;">Address:</span>
    <span style="margin-left: 20px;width: 150px;">19190 Pacific Avenue Suit No 2145, Dallas, TX 75201<br></span>
</p>
<p>
    <span style="width: 150px;">Website:</span>
    <span style="margin-left: 20px;">www.dealseverwhere.com<br></span>
</p>
<p>
    <span style="width: 150px;">Phone Number:</span>
    <span style="margin-left: 20px;width: 150px;">214253456874<br></span>
</p>
</body>
</html>
