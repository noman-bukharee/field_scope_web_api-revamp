<?php

class WebNotification
{
    public function __construct()
    {
    }
}