<?php
/**
 * Created by PhpStorm.
 * User: dnasir
 * Date: 11/20/2019
 * Time: 2:33 PM
 */

//namespace App\Exports;
////
////use App\Models\Tag;
////use Concerns;
////use Maatwebsite\Excel\Concerns\Exportable;
////
////use Excel
////
////
////class TagExport  extends \Maatwebsite\Excel\Files\NewExcelFile
////{
////    use Exportable;
////
////    public function query()
////    {
////
////        return Tag::all();
////    }
////}