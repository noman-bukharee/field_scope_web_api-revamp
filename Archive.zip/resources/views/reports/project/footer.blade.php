<table style="width:100%;background: #00ade6;margin-top:80px;bottom:0;">
    <tr>
        <td style="color:white;width:35%;padding:20px;">Powered by: <strong>FieldScope</strong></td>
        <td style="color:white;width:40%;"></td>
        <td style="color:white;width:25%;padding:20px;text-align: right;">Page: {PAGENO} of {nb}</td>
    </tr>
</table>