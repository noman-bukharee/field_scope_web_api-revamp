
<table style="width:100%;border-spacing: 0;">
    <tr>
        <td style="width:50%;background:#00ade6;">
            <table style="width:100%;padding-left:20px;">
                <tr style="width:100%;">
                    <td  style="color:white; width:30%;">Project Name:</td>
                    <td  style="color:white; width:20%;"></td>
                    <td  style="color:white;width:50%;">Test Customer</td>
                </tr>
                <tr>
                    <td  style="color:white; width:30%;">Address:</td>
                    <td  style="color:white; width:20%;"></td>
                    <td  style="color:white;width:50%;">St#1</td>
                </tr>
                <tr>
                    <td  style="color:white;width:30%;">City, State, Zip:</td>
                    <td  style="color:white; width:20%;"></td>
                    <td  style="color:white;width:50%;">Abc Xyz 123</td>
                </tr>
            </table>
        </td>

        <td  style="width:50%;background:#114050;">
            <table style="padding: 5px 20px;">
                <tr>
                    <td style="color:white;width:30%;">Location Verified:</td>
                    <td style="color:white; width:20%;"></td>
                    <td style="color:white;width:50%;">Lat:25.1231666, LONG:12.2661613</td>
                </tr>
                <tr>
                    <td style="color:white;width:30%;">Inspector:</td>
                    <td style="color:white;width:20%;"></td>
                    <td style="color:white;width:50%;">Test User</td>
                </tr>
                <tr>
                    <td style="color:white;width:30%;">Claim #:</td>
                    <td style="color:white;width:20%;"></td>
                    <td style="color:white;width:50%;">H01254232</td>
                </tr>
                <tr>
                    <td style="color:white;width:30%;width:30%;">Inspaction Date:</td>
                    <td style="color:white;width:20%;"></td>
                    <td style="color:white;width:50%;">9/7/2019</td>
                </tr>
            </table>
        </td>
    <tr>
</table>
<table style="width:100%;">
    <tr style="width:100%;">
        <td style="width:30%;"></td>
        <td style="width:40%;"><h1 style="text-align:center;">Component List</h1></td>
        <td style="width:30%;"></td>

    </tr>
</table>
<table style="width:100%;">
    <tr>
        <td style="width:50%;">
            <table style="width:100%;">
                <tr style="width:100%;">
                    <th style="width:50%;"><h3 style="padding-left:100px; margin-bottom: 5px;">Roof</h3></th>
                    <th style="width:50%;"></th>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">Pipe Fleshing</td>
                    <td style="padding-left:100px; ">2</td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">Small Chimneys</td>
                    <td style="padding-left:100px; ">1</td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">Painted Box Vent</td>
                    <td style="padding-left:100px; ">8</td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">Gutter Apron</td>
                    <td style="padding-left:100px; ">Yes</td></td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">Drip Edge</td>
                    <td style="padding-left:100px; ">Yes</td></td>
                </tr>

            </table>
        </td>
        <td style="width:50%;">
            <table></table>
        </td>
    </tr>
</table>
<table style="width:100%;">
    <tr>
        <td style="width:50%;">
            <table style="width:100%;">
                <tr><th><h3 style="margin-left: 82px;">Gutters</h3></th></tr>
                <tr style="width:100%;">
                    <th style="width:50%;"><h3 style="padding-left:192px;margin-bottom: 5px;">Front Elevation</h3></th>
                    <th style="width:50%;"></th>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">A-Elbow</td>
                    <td style="padding-left:100px; ">3</td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">B-Elbow</td>
                    <td style="padding-left:100px; ">1</td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">Outside Miter</td>
                    <td style="padding-left:100px; ">1</td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">Inside Miter</td>
                    <td style="padding-left:100px; ">2</td></td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">3 x 4 Downspout</td>
                    <td style="padding-left:100px; ">23'</td></td>
                </tr>

            </table>
        </td>
        <td style="width:50%;">
            <table></table>
        </td>
    </tr>
</table>
<table style="width:100%;">
    <tr>
        <td style="width:50%;">
            <table style="width:100%;">
                <tr style="width:100%;">
                    <th style="width:50%;"><h3 style="padding-left:192px;margin-bottom: 5px;">Right Elevation</h3></th>
                    <th style="width:50%;"></th>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">A-Elbow</td>
                    <td style="padding-left:100px; ">3</td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">B-Elbow</td>
                    <td style="padding-left:100px; ">1</td>
                </tr>
                <tr style="width:100%;">
                    <td style="padding-left:210px;">Outside Miter</td>
                    <td style="padding-left:100px; ">1</td>
                </tr>

                <tr style="width:100%;">
                    <td style="padding-left:210px;">3 x 4 Downspout</td>
                    <td style="padding-left:100px; ">23'</td></td>
                </tr>

            </table>
        </td>
        <td style="width:50%;">
            <table></table>
        </td>
    </tr>
</table>
<table style="width:100%;background: #00ade6;margin-top:180px;">
    <tr>
        <td style="width:50%;padding:20px 50px;">
            <table>
                <tr>
                    <td style="color:white;">Powerd by:</td>
                    <td style="color:white;"><strong>FieldScope</strong></td>
                </tr>
            </table>
        </td>
        <td style="width:50%;padding:20px 50px;">
            <table style="width:100%;">
                <tr>
                    <td style="width:80%;"></td>
                    <td style="width:4%;color:white;">Page:</td>
                    <td style="width:16%;color:white;">1 of 3</td>

                </tr>
            </table>
        </td>
    </tr>
</table>